class Connector:
    def __init__(self):
        pass