""" Compact LINE messenger module
"""

# thrift
from thrift.protocol.TCompactProtocol import TCompactProtocolFactory
from thrift.transport.TTransport import TTransportBase

# service
from service.ttypes import *
from service import LineService

# group service
from groups.ttypes import *
from groups import TalkService

# other
from contextlib import contextmanager
from io import BytesIO
from threading import Thread
import httplib2,threading
import pickle
import hashlib
import time
import json,orjson
import os,sys
import queue ,random ,asyncio
import copy
import asyncio , json,requests, shutil
from aiohttp import ClientSession
MAX_CONNECTIONS = 200
def readJson(filename):
    with open(filename) as f:
        data = json.load(f)
    return data


def writeJson(filename, data):
    with open(filename, "w") as f:
        json.dump(data, f, indent=4, sort_keys=True)
        f.close()
    return

def randomCount():
	num = "0123456789"
	x = random.choice(num)
	return x

def ModThriftClient(client):

    class ThriftClient:
        def __init__(self, client, transport):
            self._iprot = self._oprot = client._iprot.getProtocol(transport)
            if not self._iprot is self._oprot:
                self._oprot = client._oprot.getProtocol(transport)
            self._seqid = client._seqid

    def __init__(self, transport, iProtocolFactory, oProtocolFactory=None):
        self._iprot = self._oprot = iProtocolFactory
        if oProtocolFactory is not None:
            self._oprot = oProtocolFactory
        self._trans = transport
        self._seqid = 0

    setattr(client, "__init__", __init__)

    for name in dir(client):
        if (name[:2] == "__" and name[-2:] == "__") or name[:5] in ["send_", "recv_"]:
            continue

        if all(hasattr(client, "_".join([key, name])) for key in ["send", "recv"]):
            def create(func):
                send = getattr(client, "send_%s" % (func))
                recv = getattr(client, "recv_%s" % (func))
                def wrapper(self, *args, **kwargs):
                    with self._trans.getTransport() as transport:
                        client = ThriftClient(self, transport)
                        send(client, *args, **kwargs)
                        result = recv(client)
                    return result
                return wrapper

            setattr(client, name, create(name))

    return client


class LINE:
    """ LINE """

    class Config:
        """ LINE Config """

        rancount1 = randomCount()
        rancount2 = randomCount()
        rancount3 = randomCount()
        rancount4 = randomCount()
        #USER_AGENT = "Line/11.12.0 A5012F 14.4098.92939495{}{}{}{}".format(rancount1,rancount2,rancount3,rancount4)
        #APPLICATION = "IOS_RC\t11.12.0\tiOS\t14.4098.92939495{}{}{}{}".format(rancount1,rancount2,rancount3,rancount4)
        #USER_AGENT = "LLA/2.9.1 SM-J320G 10.1.1"
        #PPLICATION = "DESKTOPWIN	5.20.2	DESKTOP-1EJCDDQ	10.0"
        #USER_AGENT = "LLA/2.9.1 SM-J320G 5.1.1" 
        #APPLICATION = "CHANNELCP	2.9.9	Android OS	10.1.1"
        #USER_AGENT = "LLA/2.17.0 LDN-L21 8.0.0"
        #APPLICATION = "ANDROIDLITE	2.17.1	Android OS	8.0.0" 
        #APPLICATION = "CHROMEOS\t2.3.9\tChrome OS\t2.1.5"
        
        USER_AGENT = "Line/11.0.0 iPhone11,8 13.5.1" #"LLA/2.15.0 MI 8 10"
        APPLICATION = "IOS\t11.0.0\tiOS\t{}" .format(randomCount())

        # Config
        REALTIME_CHATS = False
        
        FETCH_OPS_COUNT = 100
        
        
        # Keeper
        KEEPER_FILE_EXTENSION_NAME = "keeper"
        KEEPER_THREAD = False
        KEEPER_THREAD_SLEEP_INTERVAL = 10

        # Connection
        LINE_HOST =  "https://legy-jp-addr-long.line.naver.jp"
        #LINE_HOST =  "https://gd2.line.naver.jp"
        #LINE_HOST = "https://jp.never.line.android"
        #LINE_HOST = "https://ga2.line.naver.jp"
        TALK_PATH = "/S4"
        POLL_PATH = "/P4"

        # Service
        CONNECTOR = {
            "talk": (TALK_PATH, LineService.Client),
            "poll": (POLL_PATH, LineService.Client),
            "newtalk": (TALK_PATH, TalkService.Client),
            "newpoll": (POLL_PATH, TalkService.Client),
        }
        PROTOCOL = TCompactProtocolFactory

    class Keeper:
        """ LINE Keeper """
        __slots__ = {
            "token": None,
            "localRev": 0,
            "globalRev": 0,
            "individualRev": 0
        }

        def __init__(keeper, token):
            for attr, value in keeper.__slots__.items():
                setattr(keeper, attr, value)
            keeper.token = token
            keeper.load()

            if LINE.Config.KEEPER_THREAD:
                threading.Thread(target=keeper.auto, daemon=True).start()

        def load(keeper):
            try:
                with open(".".join([hashlib.md5(keeper.token.encode("utf-8")).hexdigest(), LINE.Config.KEEPER_FILE_EXTENSION_NAME]), "rb") as f:
                    for attr, value in pickle.load(f).items():
                        if attr in keeper.__slots__:
                            setattr(keeper, attr, value)
            except (FileNotFoundError, EOFError, pickle.UnpicklingError):
                return False
            return True

        def dump(keeper):
            return pickle.dumps({attr: getattr(keeper, attr, None) for attr in keeper.__slots__})

        def save(keeper):
            with open(".".join([hashlib.md5(keeper.token.encode("utf-8")).hexdigest(), LINE.Config.KEEPER_FILE_EXTENSION_NAME]), "wb+") as f:
                f.write(keeper.dump())

        def auto(keeper):
            while True:
                keeper.save()
                time.sleep(LINE.Config.KEEPER_THREAD_SLEEP_INTERVAL)

    class Session:
        """ LINE Session """

        class THttpClient:

            class Transport(TTransportBase):
                """ LINE Session Transport """

                def __init__(transport, client):
                    transport.client = client
                    transport.http = None
                    transport.last_read = 0
                    transport.wbuf = BytesIO()
                    transport.lock = threading.Lock()

                def isOpen(transport):
                    return transport.http is not None

                def open(transport):
                    transport.http = httplib2.Http(disable_ssl_certificate_validation=True)

                def close(transport):
                    if transport.isOpen():
                        transport.http.close()
                    transport.http = None
                    transport.last_read = 0
                    
                def read(transport, sz):
                    max_sz = transport.last_read + sz
                    min_sz = transport.last_read
                    transport.last_read = max_sz
                    return transport.data[min_sz:max_sz]

                def write(transport, buf):
                    transport.wbuf.write(buf)

                def flush(transport):
                    if not transport.isOpen():
                        transport.open()
                    data = transport.wbuf.getvalue()
                    transport.wbuf = BytesIO()
                    headers = {**{"Content-Type": "application/x-thrift"}, **transport.client.session.headers}
                    transport.response, transport.data = transport.http.request(transport.client.url, "POST", headers=headers, body=data)
                    transport.code = transport.response.status
                    transport.message = transport.response.reason
                    transport.headers = transport.response
                    transport.last_read = 0

            def __init__(self, client):
                self.client = client
                self.transportQueue = queue.LifoQueue(MAX_CONNECTIONS)
                self.semaphore = threading.BoundedSemaphore(MAX_CONNECTIONS)

            def createTransport(self):
                return self.Transport(self.client)

            @contextmanager
            def getTransport(self):
                self.semaphore.acquire()
                try:
                    transport = self.transportQueue.get(block=False)
                except queue.Empty:
                    transport = self.createTransport()
                try:
                    yield transport
                finally:
                    self.transportQueue.put(transport)
                    self.semaphore.release()

        class Client:
            """ LINE Session Client """
        
            def __init__(client, session, path, service):
                client.session = session
                client.path = path
                client.url = session.line.config.LINE_HOST + client.path
                client.transport = LINE.Session.THttpClient(client)
                client.service = ModThriftClient(copy.deepcopy(service))(client.transport, session.line.config.PROTOCOL())

        def __init__(session, line):
            assert isinstance(line, LINE)
            session.line = line
            session.headers = {
                "User-Agent": line.config.USER_AGENT,
                "X-Line-Application": line.config.APPLICATION,
                "X-Line-Access": session.line.keeper.token,
                "X-lal": "in_id",
            }
            session.connector = {name: LINE.Session.Client(session, *value) for name, value in line.config.CONNECTOR.items()}
            

        def __getattr__(session, key):
            if key in session.connector: return session.connector[key].service

    class RequestSequence:
        """ LINE Request Sequence """
    
        def __init__(reqSeq):
            reqSeq._map = {}
        
        def __getitem__(reqSeq, key):
            if key not in reqSeq._map:
                reqSeq._map[key] = -1
            reqSeq._map[key] += 1
            return reqSeq._map[key]

        def __setitem__(reqSeq, key, value):
            reqSeq._map[key] = value

        def __delitem__(reqSeq, key):
            del reqSeq._map[key]
            

    class RealtimeChats:
        """ LINE Realtime Chats """
        
        class Chat:
            __slots__ = (
                "chatMid",
                "chatName",
                "type",
                "members",
                "invites",
            )
        
            def __init__(rtchat, chat):
                rtchat.chatMid = chat.chatMid
                rtchat.chatName = chat.chatName
                rtchat.type = chat.type
                if rtchat.type in [ChatType.GROUP, ChatType.ROOM]:
                    rtchat.members = list(chat.extra.groupExtra.memberMids)
                    rtchat.invites = list(chat.extra.groupExtra.inviteeMids)
                else:
                    rtchat.members = []
                    rtchat.invites = []

            def __repr__(rtchat):
                return "%s(%s)" % (rtchat.__class__.__name__, ", ".join(["%s=%r" % (key, getattr(rtchat, key, None)) for key in rtchat.__slots__]))

        __type__ = {
            ChatType.GROUP: "groups",
            ChatType.ROOM: "rooms",
            ChatType.PEER: "peers",
        }
    
        def __init__(rtc, line):
            rtc.line = line
            rtc.groups = {}
            rtc.rooms = {}
            rtc.peers = {}

        def __setitem__(rtc, chatMid, chat):
            data = getattr(rtc, rtc.__type__[chat.type])
            data[chatMid] = LINE.RealtimeChats.Chat(chat)
        
        def __delitem__(rtc, chatMid):
            for key in rtc.__type__.values():
                data = getattr(rtc, key)
                if chatMid in data:
                    del data[chatMid]
        
        def __getitem__(rtc, chatMid):

            for key in rtc.__type__.values():
                data = getattr(rtc, key)
                if chatMid in data:
                    return data[chatMid]

            if not rtc.line.config.REALTIME_CHATS:
                return LINE.RealtimeChats.Chat(Chat())

            chat = rtc.line.getChat(chatMid)
            if not chat: return LINE.RealtimeChats.Chat(Chat())
            rtc[chatMid] = chat
            return rtc[chatMid]

        def __call__(rtc, op):

            # invite to chat
            if op.type in [OperationType.INVITE_INTO_GROUP, OperationType.NOTIFIED_INVITE_INTO_GROUP, OperationType.INVITE_INTO_CHAT, OperationType.NOTIFIED_INVITE_INTO_CHAT]:
                chat = rtc[op.param1]
                if op.param3:
                    for mid in op.param3.split("\x1e"):
                        if mid not in chat.invites:
                            chat.invites.append(mid)

            # cancel chat invitation
            if op.type in [OperationType.NOTIFIED_CANCEL_INVITATION_GROUP, OperationType.CANCEL_INVITATION_GROUP, OperationType.CANCEL_CHAT_INVITATION, OperationType.NOTIFIED_CANCEL_CHAT_INVITATION]:
                chat = rtc[op.param1]
                if op.param3:
                    for mid in op.param3.split("\x1e"):
                        if mid in chat.invites:
                            chat.invites.remove(mid)

            # reject chat invitation
            if op.type in [OperationType.REJECT_GROUP_INVITATION, OperationType.NOTIFIED_REJECT_GROUP_INVITATION, OperationType.REJECT_CHAT_INVITATION]:
                chat = rtc[op.param1]
                if op.param2:
                    for mid in op.param2.split("\x1e"):
                        if mid in chat.invites:
                            chat.invites.remove(mid)

            # delete other from chat
            if op.type in [OperationType.KICKOUT_FROM_GROUP, OperationType.NOTIFIED_KICKOUT_FROM_GROUP, OperationType.DELETE_OTHER_FROM_CHAT, OperationType.NOTIFIED_DELETE_OTHER_FROM_CHAT]:
                chat = rtc[op.param1]
                if op.param3:
                    for mid in op.param3.split("\x1e"):
                        if mid in chat.members:
                            chat.members.remove(mid)
                if op.param2:
                    if op.param2 == rtc.line.profile.mid:
                        del rtc[op.param1]

            # accept chat invitation
            if op.type in [OperationType.ACCEPT_GROUP_INVITATION, OperationType.NOTIFIED_ACCEPT_GROUP_INVITATION, OperationType.ACCEPT_CHAT_INVITATION, OperationType.NOTIFIED_ACCEPT_CHAT_INVITATION]:
                chat = rtc[op.param1]
                if op.param2:
                    for mid in op.param2.split("\x1e"):
                        if mid not in chat.members:
                            chat.members.append(mid)

            # leave chat
            if op.type in [OperationType.LEAVE_GROUP, OperationType.NOTIFIED_LEAVE_GROUP, OperationType.DELETE_SELF_FROM_CHAT, OperationType.NOTIFIED_DELETE_SELF_FROM_CHAT]:
                chat = rtc[op.param1]
                if op.param2:
                    for mid in op.param2.split("\x1e"):
                        if mid in chat.members:
                            chat.members.remove(mid)

                if op.type in [OperationType.LEAVE_GROUP, OperationType.DELETE_SELF_FROM_CHAT]:
                    del rtc[op.param1]

            if op.type in [26,25]:
                msg = op.message
                if msg.contentType == 18:
                    key = msg.contentMetadata["LOC_KEY"]
                    args = msg.contentMetadata["LOC_ARGS"].split("\x1e")
                    chat = rtc[op.param1]
                    if key == "C_MI": # invite
                        if args[1] not in chat.invites:
                            chat.invites.append(args[1])
                    if key == "C_IC": # cancel
                        if args[1] in chat.invites:
                            chat.invites.remove(args[1])




    def __init__(line, keeper):
        assert isinstance(keeper, LINE.Keeper)
        line.config = LINE.Config()
        line.keeper = keeper
        line.session = LINE.Session(line)
        line.reqSeq = LINE.RequestSequence()
        line.chats = LINE.RealtimeChats(line)
        line.profile = line.getProfile()
        line.Mid = line.getProfile().mid
        line.contacts = line.getAllContactIds()
        line.authToken = line.keeper.token
        line.header = line.getHeader()
        line.limit = False
        line.count = {"kick":0,"invite":0,"cancel":0,"msg":0,"accept":0,"allreq":0}
        line.logo = "ChenZi"
        line.prefix = ","
        line._messageReq = {}
        #line.operationSelf = asyncio.get_event_loop()

    def getHeader(line):
    	Headers={'User-Agent': line.config.USER_AGENT, 'X-Line-Application': line.config.APPLICATION, 'X-Line-Access': line.keeper.token} #, 'X-Line-Carrier': '51089, 1-0' }
    	return Headers

    def getProfile(line, syncReason=SyncReason.FULL_SYNC):
        line.profile = line.session.talk.getProfile(syncReason)
        return line.profile

    def getContact(line, userIds):
    	return line.session.talk.getContact(userIds)

    def createChat(line, name, targetUserMids=[]):
    	return line.session.talk.createChat(CreateChatRequest(0, 0, name, targetUserMids, ''))
    	
    def stateQr(line, to):
    	gc = line.getChats([to],False,False)
    	state=gc[0].extra.groupExtra.preventedJoinByTicket
    	return state

    def getMidUser(line, to):
    	gc = line.getChats([to],True,True)
    	mem=gc[0].extra.groupExtra.memberMids
    	pen=gc[0].extra.groupExtra.inviteeMids
    	return mem,pen

    def accByKicked(line, to,ticket):
    	gc = line.getChats([to],False,False)
    	state=gc[0].extra.groupExtra.preventedJoinByTicket
    	if not state:
    		return line.session.talk.acceptChatInvitationByTicket(AcceptChatInvitationByTicketRequest(line.reqSeq["acceptChatInvitationByTicket"], chatMid=to, ticketId=ticket))

    def updateProfile(line, objek):
    	return line.session.talk.updateProfile(0, objek)

    def unsendMessage(line, msgId):
        return line.session.talk.unsendMessage(line.reqSeq["unsendMessage"], msgId)

    def sendMessage2(line, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to = to
        msg._from = line.profile.mid
        msg.text = text
        msg.contentType = contentType
        msg.contentMetadata = contentMetadata
        line.count["msg"] += 1
        if to not in line._messageReq:
            line._messageReq[to] = -1
        line._messageReq[to] += 1
        return line.session.newtalk.sendMessage(line._messageReq[to], msg)

    def generateReplyMessage(line, relatedMessageId):
        msg = Message()
        msg.relatedMessageServiceCode = 1
        msg.messageRelationType = 3
        msg.relatedMessageId = str(relatedMessageId)
        return msg

    def sendReplyMessage(line, relatedMessageId, to, text, contentMetadata={}, contentType=0):
        msg = line.generateReplyMessage(relatedMessageId)
        msg.to = to
        msg.text = text
        msg.contentType = contentType
        msg.contentMetadata = contentMetadata
        line.count["msg"] += 1
        if to not in line._messageReq:
            line._messageReq[to] = -1
        line._messageReq[to] += 1
        return line.session.newtalk.sendMessage(line._messageReq[to], msg)

    def sendMessageObject(line, msg):
        return line.session.talk.sendMessage(line.reqSeq["sendMessage"], msg)

    def sendMentionV2(line, id, to, text="", mids=[], isUnicode=False):
        arrData = ""
        arr = []
        mention = "@noobiez "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ""
            unicode = ""
            if isUnicode:
                for mid in mids:
                    unicode += str(texts[mids.index(mid)].encode('unicode-escape'))
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx) if unicode == textx else len(textx) + unicode.count('U0')
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            else:
                for mid in mids:
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx)
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            textx += str(texts[len(mids)])
        else:
            raise Exception("Invalid mention position")
        line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0, msgid=id)

    def sendMention2(line,to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        line.sendMessage(to, textx, {'AGENT_LINK': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQE1AudGwwa9foK_ajhoKCnffSbO6WJQFMj-g&usqp=CAU','AGENT_ICON': "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQE1AudGwwa9foK_ajhoKCnffSbO6WJQFMj-g&usqp=CAU",'AGENT_NAME': ps,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)        


    def sendMessage(line, to, text, contentMetadata={}, contentType=0,msgid=None):
        #msg = line.generateReplyMessage(relatedMessageId)
        msg = Message()
        if 'MENTION' in contentMetadata.keys()!=None:
            try:
                msg.relatedMessageId = str(line.talk.getRecentMessagesV2(to, 10)[0].id)
                msg.relatedMessageServiceCode = 1
                msg.messageRelationType = 3
            except:
                pass
        if msgid != None:
            msg.relatedMessageId = str(msgid)
            msg.relatedMessageServiceCode = 1
            msg.messageRelationType = 3
        msg.to, msg._from = to, line.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in line._messageReq:
            line._messageReq[to] = -1
        line._messageReq[to] += 1
        line.count["msg"] += 1
        return line.session.talk.sendMessage(line._messageReq[to], msg)
        

    def sendContact(line, to, mid):
        return line.sendMessage(to, "", {"mid": mid}, ContentType.CONTACT)

    def getAllChatMids(line, withMemberChats=True, withInvitedChats=True, syncReason=SyncReason.FULL_SYNC):
        return line.session.talk.getAllChatMids(request=GetAllChatMidsRequest(withMemberChats=withMemberChats, withInvitedChats=withInvitedChats), syncReason=syncReason)

    def getChats(line, chatMids, withMembers=True, withInvitees=True):
        return line.session.talk.getChats(GetChatsRequest(chatMids=chatMids, withMembers=withMembers, withInvitees=withInvitees)).chats

    def getCompactGroup(line, groupId):
        return line.session.newtalk.getCompactGroup(groupId)

    def getGroup(line, groupId):
        return line.session.newtalk.getGroup(groupId)

    def updateGroup(line, groupId):
        return line.session.newtalk.updateGroup(0, groupId)
    
    def getChat(line, chatMid, withMembers=True, withInvitees=True):
        chats = line.getChats([chatMid], withMembers=withMembers, withInvitees=withInvitees)
        if chats:
            return chats[0]

    def acceptChatInvitation(line, chatMid):
    	line.count["allreq"] += 1
    	try:line.session.talk.acceptChatInvitation(AcceptChatInvitationRequest(line.reqSeq["acceptChatInvitation"], chatMid=chatMid));return
    	except:return
         
    def updateChat(line, chatId, updatedAttribute):
        line.count["allreq"] += 1
        return line.session.talk.updateChat(UpdateChatRequest(line.reqSeq["updateChat"], chatId, updatedAttribute))

    def acceptChatInvitationByTicket(line, chatMid, ticketId):
        line.count["accept"] += 1
        return line.session.talk.acceptChatInvitationByTicket(AcceptChatInvitationByTicketRequest(line.reqSeq["acceptChatInvitationByTicket"], chatMid=chatMid, ticketId=ticketId))

    def acceptGroupInvitationByTicket(line, groupId, ticketId):
        line.count["accept"] += 1
        return line.session.newtalk.acceptGroupInvitationByTicket(0, groupId, ticketId)

    def inviteIntoChat(line, chatMid, targetUserMids):
        line.count["invite"] += 1
        return line.session.talk.inviteIntoChat(InviteIntoChatRequest(line.reqSeq["inviteIntoChat"], chatMid=chatMid, targetUserMids=set(targetUserMids)))

    def cancelChatInvitation(line, chatMid, targetUserMids):
        line.count["cancel"] += 1
        return line.session.talk.cancelChatInvitation(CancelChatInvitationRequest(line.reqSeq["cancelChatInvitation"], chatMid=chatMid, targetUserMids=set({targetUserMids})))

    def cancelGroupInvitation(line, groupId, userIds):
        line.count["cancel"] += 1
        return line.session.newtalk.cancelGroupInvitation(0, groupId, [userIds])
        	
    def rejectChatInvitation(line, chatMid):
        line.count["allreq"] += 1
        return line.session.talk.rejectChatInvitation(CancelChatInvitationRequest(line.reqSeq["rejectChatInvitation"], chatMid=chatMid))

    def deleteOtherFromChat(line, chatMid, targetUserMids):
        line.count["kick"] += 1
        return line.session.talk.deleteOtherFromChat(DeleteOtherFromChatRequest(line.reqSeq["deleteOtherFromChat"], chatMid=chatMid, targetUserMids=set(targetUserMids)))
    

    def deleteSelfFromChat(line, chatMid):
        line.count["allreq"] += 1
        return line.session.talk.deleteSelfFromChat(DeleteSelfFromChatRequest(line.reqSeq["deleteSelfFromChat"], chatMid=chatMid))

    def reissueChatTicket(line, groupMid):
        line.count["allreq"] += 1
        return line.session.talk.reissueChatTicket(ReissueChatTicketRequest(line.reqSeq["reissueChatTicket"], groupMid=groupMid)).ticketId
        
    def findChatByTicket(line, ticketId):
        line.count["allreq"] += 1
        return line.session.talk.findChatByTicket(FindChatByTicketRequest(ticketId)).chat

    def getAllContactIds(line, syncReason=SyncReason.FULL_SYNC):
        return line.session.talk.getAllContactIds(syncReason)

    def findAndAddContactsByMid(line, mid, type=ContactType.MID, reference=""):
        line.count["allreq"] += 1
        if mid in line.contacts or mid == line.profile.mid: return
        return line.session.talk.findAndAddContactsByMid(line.reqSeq["findAndAddContactsByMid"], mid, type, reference)

    def getRecentMessagesV2(line, chatId, count=1001):
        line.count["allreq"] += 1
        return line.session.talk.getRecentMessagesV2(chatId,count)

    def sendMention(line, to, text='',  mids=[]):
    	arrData = ""
    	arr = []
    	mention = "@Noobiez "
    	if mids == []:
    		raise Exception("Invalid mids")
    	if "@!" in text:
    		if text.count("@!") != len(mids):
    			raise Exception("Invalid mids")
    		texts = text.split("@!")
    		textx = ""
    		for mid in mids:
    			textx += str(texts[mids.index(mid)])
    			slen = len(textx)
    			elen = str(len(textx) + len(mention)-1)
    			arrData = {'S':str(slen),'E':str(elen),'M':mid}
    			arr.append(arrData)
    			textx += mention
    		textx += str(texts[len(mids)])
    	else:
    		textx = ""
    		slen = len(textx)
    		elen = str(len(textx) + len(mention)-1)
    		arrData = {'S':str(slen),'E':str(elen),'M':mids[0]}
    		arr.append(arrData)
    		textx += mention + str(text)
    	line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

    def sendMentionWithList(line, to, info, list):
    	h = [a for a in list]
    	k = len(h)//20
    	for aa in range(k+1):
    		if aa == 0: dd = f'╭ ◤  {info} ◥'; no=aa
    		else: dd = ''; no=aa*20
    		msgas = dd
    		for a in h[aa*20:(aa+1)*20]:
    			no+=1
    			if no == len(h): msgas+='\n│▸{}. @!'.format(no)
    			else: msgas += '\n│▸{}. @!'.format(no)
    		msgas += '\n╰ ◣ '+line.logo+' ◢'
    		line.sendMention(to, msgas, h[aa*20:(aa+1)*20])
    def sendMention2(self,to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@UserNotFound "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        try:
            try:
                if 'kolori' in ps:contact = self.getContact(ps.split('##')[1])
                else:contact = self.getContact(to)
                cu = "http://profile.line-cdn.net/" + contact.pictureStatus
                cc = str(contact.displayName)
            except Exception as e:
                cdb = self.getContact(self.profile.mid)
                cc = str(cdb.displayName)
                cu = "http://profile.line-cdn.net/" + cdb.pictureStatus
            self.sendMessage(to, textx, {'AGENT_LINK': "line://app/1602687308-DgedGk9A?type=fotext&text=I'm%20RhyN",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'AGENT_NAME':ps,'MSG_SENDER_ICON':cu,'MSG_SENDER_NAME':cc,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except:
            try:
                self.sendMessage(to, textx, {'AGENT_LINK': "line://app/1602687308-DgedGk9A?type=fotext&text=I'm%20RhyN",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'MSG_SENDER_NAME': self.getContact(to).displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + self.getContact(to).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
            except:
                try:
                    self.sendMessage(to, textx, {'AGENT_LINK': "line://app/1602687308-DgedGk9A?type=fotext&text=I'm%20RhyN",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'MSG_SENDER_NAME': self.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + self.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                except:
                    self.sendMessage(to, textx, {'AGENT_LINK': "line://app/1602687308-DgedGk9A?type=fotext&text=I'm%20RhyN",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'AGENT_NAME':ps,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)


    def dataMention(self, to, text, data, ps=''):
        if(data == [] or data == {}):return
        k = len(data)//20
        for aa in range(k+1):
            if aa == 0:dd = '╭「 {} 」{}'.format(text,ps);no=aa
            else:dd = '├「 {} 」─{}'.format(text,ps);no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n╰{}. @!'.format(no)
                else:msgas+='\n│{}. @!'.format(no)
            self.sendMention2(to, msgas,' 「 {} 」'.format(text), data[aa*20 : (aa+1)*20])

    
    def downloadMsg(line, msgid, name= ".bin"):
        path = '{}'.format(name)
        r = requests.session().get( 'https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+msgid, headers=line.header, stream=True)
        if r.status_code == 200:
            with open(path, 'wb') as f:
                shutil.copyfileobj(r.raw, f)
            return path
        else:
            raise Exception('Download object failure.')
    def removeAllMessages(line, lastMessageId):
    	return line.session.talk.removeAllMessages(line.reqSeq["removeAllMessages"], lastMessageId)
    
    def realFetchOps(line):
        try:
            ops = line.session.poll.fetchOps(line.keeper.localRev, line.config.FETCH_OPS_COUNT, line.keeper.globalRev, line.keeper.individualRev)
        except : #EOFError
            # timeout
            return []
        for op in ops:
        	#if op.revision > line.keeper.localRev:
        		if op.type != OperationType.END_OF_OPERATION:
        			line.keeper.localRev = max(line.keeper.localRev, op.revision)
        			#line.chats(op)
        		else:
        			if op.param1:
        				a, _, _ = op.param1.partition("")
        				line.keeper.individualRev = int(a)
        			if op.param2:
        				a, _, _ = op.param2.partition("")
        				line.keeper.globalRev = int(a)
        		#print(line.keeper.localRev)
        return ops
        

    def updateChatURL(line,to, boolean):
    	gc = line.getChats([to],False,False)
    	gc[0].extra.groupExtra.preventedJoinByTicket = boolean
    	return line.updateChat(gc[0],4)
   
   