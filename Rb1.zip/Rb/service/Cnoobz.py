from lesting import Lesting
from line import LINE
import threading
import time, asyncio,os,sys,orjson,json
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser

now = time.time()
startTime = "2021-06-7 13:19:25.425129"
duedate = parser.parse (startTime) + relativedelta(days= 7)
timeleft = duedate - datetime.now()
days,seconds = timeleft.days, timeleft.seconds
hours = seconds / 3600
minutes = (seconds / 60) % 60
exp = int(days) * hours * 60

with open("lop.json", "rb") as r:
	lop = json.load(r)
num = lop['token']
server = lop['server']
def saved():
    with open("lop.json", "wb") as d:
        d.write(orjson.dumps(lop, option=orjson.OPT_INDENT_2))
def cekSN(tx):
	num = "1234567890"
	for t in tx:
		if t in num:
			return True
	return False
if "sysname" not in lop:
	sname = input("put sysname: ")
	cek = cekSN(sname)
	if cek:
		lop["sysname"] = str(sname)
		file = lop["sysname"]
		saved()
	else:
		print("please use Alphanumeric example (c1)")
		python = sys.executable
		os.execl(python, python, *sys.argv)
else:
	if lop["sysname"] == "":
		sname = input("put sysname: ")
		cek = cekSN(sname)
		if cek:
			lop["sysname"] = str(sname)
			file = lop["sysname"]
			saved()
		else:
			print("please use Alphanumeric example (c1)")
			python = sys.executable
			os.execl(python, python, *sys.argv)
file = lop["sysname"]
if server == '':
	s = input('\033[91m'+'put new server here: '+'\033[0m')
	lop['server'] = str(s)
	saved()
	time.sleep(1)
	python = sys.executable
	os.execl(python, python, *sys.argv)
try:
	with open('token/{}.txt'.format(file), 'r') as sname:
		tlist = sname.readlines()
		PLAIN_TOKEN = [x.strip() for x in tlist]
except:
	token = input('\033[91m'+'put new token for {}.py: '.format(file)+'\033[0m')
	m = open('token/{}.txt'.format(file), 'w')
	m.write(token)
	m.close()
	time.sleep(1)
	python = sys.executable
	os.execl(python, python, *sys.argv)
token = ''
for t in range(len(PLAIN_TOKEN)):
	if num == t:
		token = str(PLAIN_TOKEN[t])
sockaddr=(server, 8080)
lesting = Lesting()
saved()
#time.sleep(2)
try:
	n = lesting.Node(LINE(LINE.Keeper(token)),sockaddr,file)
	threading.Thread(target=n.fetch, daemon=True).start()
	threading.Thread(target=n.executor, daemon=True).start()
	threading.Thread(target=n.TCP, daemon=True).start()
except Exception as e: #ValueError
	if 'code=20' in str(e):
		print('\033[91m'+'YOU TOKEN FREZE PLEASE WAIT 1 HOURS'+'\033[0m') 
		time.sleep(3600)
	print(str(e))
	time.sleep(1)
	python = sys.executable
	os.execl(python, python, *sys.argv) 
if int(exp) >= 1:
	#print('\033[95m'+ "THE VALIDITY PERIOD EXPIRES AT ANOTHER\n {} days > {}H:{}S".format(int(days),int(hours),int(minutes))+'\033[0m' )
	while True:
		time.sleep(1)
else:
	print("TRIAL expired")