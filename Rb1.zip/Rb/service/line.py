""" Compact LINE messenger module
"""

# thrift
from thrift.protocol.TCompactProtocol import TCompactProtocolFactory
from thrift.transport.TTransport import TTransportBase

# service
from service.ttypes import *
from service import LineService

# group service
from groups.ttypes import *
from groups import TalkService

# other
from contextlib import contextmanager
from io import BytesIO
from threading import Thread
import httplib2,threading
import pickle
import hashlib
import time
import json,orjson
import os,sys
import queue ,random ,asyncio
import copy
import asyncio , json,requests, shutil
from aiohttp import ClientSession
MAX_CONNECTIONS = 200
def readJson(filename):
    with open(filename) as f:
        data = json.load(f)
    return data
#========MODELS
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
import Crypto.Cipher.PKCS1_OAEP as rsaenc
from base64 import b64encode, b64decode
from Crypto.Util.Padding import pad, unpad
from hashlib import md5, sha1
import xxhash
from datetime import datetime
import struct
import time
import json
import os
import rsa,urllib
        
def writeJson(filename, data):
    with open(filename, "w") as f:
        json.dump(data, f, indent=4, sort_keys=True)
        f.close()
    return

def randomCount():
	num = "0123456789"
	x = random.choice(num)
	return x

def ModThriftClient(client):

    class ThriftClient:
        def __init__(self, client, transport):
            self._iprot = self._oprot = client._iprot.getProtocol(transport)
            if not self._iprot is self._oprot:
                self._oprot = client._oprot.getProtocol(transport)
            self._seqid = client._seqid

    def __init__(self, transport, iProtocolFactory, oProtocolFactory=None):
        self._iprot = self._oprot = iProtocolFactory
        if oProtocolFactory is not None:
            self._oprot = oProtocolFactory
        self._trans = transport
        self._seqid = 0

    setattr(client, "__init__", __init__)

    for name in dir(client):
        if (name[:2] == "__" and name[-2:] == "__") or name[:5] in ["send_", "recv_"]:
            continue

        if all(hasattr(client, "_".join([key, name])) for key in ["send", "recv"]):
            def create(func):
                send = getattr(client, "send_%s" % (func))
                recv = getattr(client, "recv_%s" % (func))
                def wrapper(self, *args, **kwargs):
                    with self._trans.getTransport() as transport:
                        client = ThriftClient(self, transport)
                        send(client, *args, **kwargs)
                        result = recv(client)
                    return result
                return wrapper

            setattr(client, name, create(name))

    return client

class Server(object):

    def __init__(line):
        line.Headers = {}
        line.timelineHeaders = {}
        line.channelHeaders = {}
        line._session = requests.session()

    def parseUrl(line, path):
        return line.LINE_HOST_DOMAIN + path

    def urlEncode(line, url, path, params=[]):
        return url + path + '?' + urllib.parse.urlencode(params)

    def getJson(line, url, allowHeader=False, cHeaders={}):
        if allowHeader is False:
            return json.loads(line._session.get(url).text)
        else:
            if cHeaders != {}:
                return json.loads(line._session.get(url, headers=cHeaders).text)
            return json.loads(line._session.get(url, headers=line.Headers).text)

    def setHeadersWithDict(line, headersDict):
        line.Headers.update(headersDict)

    def setHeaders(line, argument, value):
        line.Headers[argument] = value

    def setTimelineHeadersWithDict(line, headersDict):
        line.timelineHeaders.update(headersDict)

    def setTimelineHeaders(line, argument, value):
        line.timelineHeaders[argument] = value

    def additionalHeaders(line, source, newSource):
        headerList={}
        headerList.update(source)
        headerList.update(newSource)
        return headerList

    def optionsContent(line, url, data=None, headers=None):
        if headers is None:
            headers=line.Headers
        return line._session.options(url, headers=headers, data=data)

    def postContent(line, url, data=None, files=None, headers=None, json=None):
        if headers is None:
            headers = line.Headers
        res = line._session.post(url, headers=headers, data=data, files=files, json=json)
        return res

    def getContent(line, url, headers=None):
        if headers is None:
            headers=line.Headers
        return line._session.get(url, headers=headers, stream=True)

    def deleteContent(line, url, data=None, headers=None):
        if headers is None:
            headers=line.Headers
        return line._session.delete(url, headers=headers, data=data)

    def putContent(line, url, data=None, headers=None):
        if headers is None:
            headers=line.Headers
        return line._session.put(url, headers=headers, data=data)

class Models(object):

    def __init__(line):
        line.lcsStart = "0005"
        line.le = "18"
        line.PUBLIC_KEY = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0LRokSkGDo8G5ObFfyKiIdPAU5iOpj+UT+A3AcDxLuePyDt8IVp9HpOsJlf8uVk3Wr9fs+8y7cnF3WiY6Ro526hy3fbWR4HiD0FaIRCOTbgRlsoGNC2rthp2uxYad5up78krSDXNKBab8t1PteCmOq84TpDCRmainaZQN9QxzaSvYWUICVv27Kk97y2j3LS3H64NCqjS88XacAieivELfMr6rT2GutRshKeNSZOUR3YROV4THa77USBQwRI7ZZTe6GUFazpocTN58QY8jFYODzfhdyoiym6rXJNNnUKatiSC/hmzdpX8/h4Y98KaGAZaatLAgPMRCe582q4JwHg7rwIDAQAB\n-----END PUBLIC KEY-----"
        line.key = RSA.importKey(line.PUBLIC_KEY)
        line.encryptKey = b"DearSakura+2021/"
        line.IV = bytes([78, 9, 72, 62, 56, 245, 255, 114, 128, 18, 123, 158, 251, 92, 45, 51])
        line.cipher = AES.new(line.encryptKey, AES.MODE_CBC, iv=line.IV)
        line.d_cipher = AES.new(line.encryptKey, AES.MODE_CBC, iv=line.IV)
        line.encEncKey()
        
    def log(line, text):
        print("[{}] {}".format(str(datetime.now()), text))
        
    def genOBSParams(line, newList, returnAs='json', ext='jpg'):
        oldList = {'name': f'CHRLINE-{int(time.time())}.{ext}','ver': '1.0'}
        if returnAs not in ['json','b64','default']:
            raise Exception('Invalid parameter returnAs')
        oldList.update(newList)
        if 'range' in oldList:
            new_range = 'bytes 0-%s\/%s' % ( str(oldList['range']-1), str(oldList['range']) )
            oldList.update({'range': new_range})
        if returnAs == 'json':
            oldList = json.dumps(oldList)
            return oldList
        elif returnAs == 'b64':
            oldList = json.dumps(oldList)
            return b64encode(oldList.encode('utf-8'))
        elif returnAs == 'default':
            return oldList
        
    def checkNextToken(line):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.tokens')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = md5(line.authToken.encode()).hexdigest()
        if os.path.exists(savePath + f"/{fn}"):
            line.authToken = open(savePath + f"/{fn}", "r").read()
            line.log(f"New Token: {line.authToken}")
            line.checkNextToken()
        return line.authToken

    def handleNextToken(line, newToken):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.tokens')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = md5(line.authToken.encode()).hexdigest()
        open(savePath + f"/{fn}", "w").write(newToken)
        line.authToken = newToken
        line.log(f"New Token: {newToken}")
        line.server.timelineHeaders['X-Line-Access'] = line.authToken
        line.server.timelineHeaders['X-Line-ChannelToken'] = line.issueChannelToken()[5] #need?
        
    def getCustomData(line):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.data')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = md5(line.profile[1].encode()).hexdigest()
        if os.path.exists(savePath + f"/{fn}"):
            line.custom_data = json.loads(open(savePath + f"/{fn}", "r").read())
        return True
        
    def saveCustomData(line):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.data')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = md5(line.profile[1].encode()).hexdigest()
        open(savePath + f"/{fn}", "w").write(json.dumps(line.custom_data))
        return True
        
    def getSqrCert(line):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.data')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = "cert.pem"
        if os.path.exists(savePath + f"/{fn}"):
            return open(savePath + f"/{fn}", "r").read()
        return None
        
    def saveSqrCert(line, cert):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.data')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = "cert.pem"
        open(savePath + f"/{fn}", "w").write(cert)
        return True
        
    def getEmailCert(line, email):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.data')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = f"{email}.crt"
        if os.path.exists(savePath + f"/{fn}"):
            return open(savePath + f"/{fn}", "r").read()
        return None
        
    def saveEmailCert(line, email, cert):
        savePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '.data')
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        fn = f"{email}.crt"
        open(savePath + f"/{fn}", "w").write(cert)
        return True
    
    def initWithAndroid(line):
        line.lcsStart = "0008"
        line.le = "7"
        line.PUBLIC_KEY = '-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsMC6HAYeMq4R59e2yRw6\nW1OWT2t9aepiAp4fbSCXzRj7A29BOAFAvKlzAub4oxN13Nt8dbcB+ICAufyDnN5N\nd3+vXgDxEXZ/sx2/wuFbC3B3evSNKR4hKcs80suRs8aL6EeWi+bAU2oYIc78Bbqh\nNzx0WCzZSJbMBFw1VlsU/HQ/XdiUufopl5QSa0S246XXmwJmmXRO0v7bNvrxaNV0\ncbviGkOvTlBt1+RerIFHMTw3SwLDnCOolTz3CuE5V2OrPZCmC0nlmPRzwUfxoxxs\n/6qFdpZNoORH/s5mQenSyqPkmH8TBOlHJWPH3eN1k6aZIlK5S54mcUb/oNRRq9wD\n1wIDAQAB\n-----END PUBLIC KEY-----'
        line.key = RSA.importKey(line.PUBLIC_KEY)
        line.encryptKey = b"DearSakura+2021/"
        line.IV = bytes([78, 9, 72, 62, 56, 245, 255, 114, 128, 18, 123, 158, 251, 92, 45, 51])
        line.encEncKey()
        print(line._encryptKey)

    def encHeaders(line, headers):
        t = headers.keys()
        data = []
        line.mFhrnmxnNF(len(t), data)
        for i in t:
            line.mFhrnmxnNF(len(i), data)
            line.wYEpEYldst(i, data)
            line.mFhrnmxnNF(len(headers[i]), data)
            line.wYEpEYldst(headers[i], data)
        o = len(data);
        data = [255 & o] + data
        data = [255 & o >> 8] + data
        return data
        
    def encEncKey(line):
        # heh
        a = rsaenc.new(line.key)
        line._encryptKey = line.lcsStart + b64encode(a.encrypt(line.encryptKey)).decode()
        
    def encData(line, data):
        _data = AES.new(line.encryptKey, AES.MODE_CBC, iv=line.IV).encrypt(pad(data, AES.block_size))
        debug = []
        return _data + line.XQqwlHlXKK(line.encryptKey, _data)
        
    def decData(line, data):
        data = pad(data, AES.block_size)
        _data = AES.new(line.encryptKey, AES.MODE_CBC, iv=line.IV).decrypt(data)
        i = 1
        data = line.yVdzCLDwMN(_data, i)
        i = 3
        return _data
        
    def mFhrnmxnNF(line, t, e):
        i = 65536 
        if t < -1 * 32768 or t >= i:
            raise Exception(t + " is incorrect for i16.")
        e.append(255 & t >> 8)
        e.append(255 & t)
        
    def wYEpEYldst(line, t, e):
        for i in range(len(t)):
            e.append(ord(t[i]))
        
    def xZVpUuXFru(t):
        if 8 == len(t):
            return t
        e = ""
        i = 0
        n = 8 - len(t)
        while i < n:
            e += "0"
            i += 1
        return e + t
        
    def pmAWhahfKx(line, t):
        e = []
        i = 0 
        n = len(t)
        while i < n:
            _i = 0
            try:
                _i = int(t[i:i + 2], 16)
            except:
                _i = 16
            e.append(_i);
            i += 2
        return e
        
    def XQqwlHlXKK(line, e, i):
        r = []
        for o in range(16):
            r.append(92 ^ e[o])
        n = xxhash.xxh32(b'',seed=0)
        s = xxhash.xxh32(b'',seed=0)
        n.update(bytes(r))
        for o in range(16):
            r[o] ^= 106
        s.update(bytes(r))
        s.update(i)
        a = s.hexdigest() # is b8a7c677?
        n.update(bytes(line.pmAWhahfKx(a)))
        c = n.hexdigest() # is 3f97d2f6?
        d = line.pmAWhahfKx(c)
        return bytes(d)
        
    def yVdzCLDwMN(line, d, i):
        return (255 & line.xnEmbaRWhy(d, i)) << 8 | 255 & line.xnEmbaRWhy(d, i+1)
    
        
    def xnEmbaRWhy(line, d, i):
        t = d[i];
        if t > 127:
            t = 0 - (t - 1 ^ 255)
        return t
        
    def getIntBytes(line, i, l=4, isCompact=False):
        if isCompact:
            _compact = line.TCompactProtocol()
            a = _compact.makeZigZag(i, 16)
            b = _compact.writeVarint(a)
            return b
        _seq = int(i).to_bytes(l, byteorder="big")
        res = []
        for value in _seq:
            res.append(value)
        return res
        
    def getStringBytes(line, text, isCompact=False):
        if text is None:
            text = ""
        text = str(text).encode()
        if isCompact:
            _compact = line.TCompactProtocol()
            sqrd = _compact.writeVarint(len(text))
        else:
            sqrd = line.getIntBytes(len(text))
        for value in text:
            sqrd.append(value)
        return sqrd
        
    def getFloatBytes(line, val):
        res = []
        for value in struct.pack('!d', val):
            res.append(value)
        return res
        
    def tryReadData(line, data, mode=1):
        _data = {}
        if mode == 0:
            data = bytes(4) + data + bytes(4)
        if data[4] == 128:
            a = 12 + data[11]
            b = data[12:a].decode()
            _data[b] = {}
            c = data[a + 4]
            id = data[a + 6]
            if id == 0:
                if c == 10:
                    a = int.from_bytes(data[a + 9:a + 15], "big")
                    _data[b] = a
                elif c == 11:
                    d = data[a + 10]
                    e = data[a + 11:a + 11 + d].decode()
                    _data[b] = e
                elif c == 12:
                    _data[b] = line.readContainerStruct(data[a + 7:])
                elif c == 13:
                    _data[b] = line.readContainerStruct(data[a + 4:])
                elif c == 14 or c == 15:
                    _data[b] = line.readContainerStruct(data[a + 4:], stopWithFirst=True)[0]
                else:
                    print(f"[tryReadData]不支援Type: {c} => ID: {id}")
            else:
                if c != 0:
                    error = {}
                    if c == 11:
                        t_l = data[a + 10]
                        error = data[a + 11:a + 11 + t_l].decode()
                    else:
                        code = data[a + 10:a + 14]
                        t_l = data[a + 20]
                        error = {
                            'code': int.from_bytes(code, "big"),
                            'message': data[a + 21:a + 21 + t_l].decode(),
                            'metadata': line.readContainerStruct(data[a + 21 + t_l:])
                        }
                        if error['message'] in ["AUTHENTICATION_DIVESTED_BY_OTHER_DEVICE", "REVOKE", "LOG_OUT"]:
                            line.is_login = False
                            raise Exception(f"LOGIN OUT: {error['message']}")
                    _data[b] = {
                        "error": error
                    }
                    print(_data)
        else:
            if data[6:24] == b"x-line-next-access":
                a = data[25]
                b = data[26:26 + a]
                line.handleNextToken(b.decode())
                data = bytes([0, 0, 0, 0]) + data[26 + a:]
                return line.tryReadData(data)
        return _data
        
    def readContainerStruct(line, data, get_data_len=False, stopWithFirst=False):
        _data = {}
        nextPos = 0
        dataType = data[0]
        id = data[2]
        if data[0] == 2:
            a = data[3]
            if a == 1:
                _data[id] = True
            else:
                _data[id] = False
            nextPos = 4
        elif data[0] == 3:
            a = int.from_bytes(data[3:4], "big")
            _data[id] = a
            nextPos = 4
        elif data[0] == 4:
            a = data[3:11]
            a = struct.unpack('!d', a)[0]
            _data[id] = a
            nextPos = 11
        elif data[0] == 8:
            a = int.from_bytes(data[3:7], "big")
            _data[id] = a
            nextPos = 7
        elif data[0] == 10:
            a = int.from_bytes(data[4:11], "big")
            _data[id] = a
            nextPos = 11
        elif data[0] == 11:
            a = int.from_bytes(data[5:7], "big")
            if a == 0:
                _data[id] = ''
                nextPos = a + 7
            else:
                b = data[7:a+7]
                try:
                    _data[id] = b.decode()
                except:
                    _data[id] = b
                nextPos = a + 7
        elif data[0] == 12:
            if data[3] == 0:
                _data[id] = {}
                nextPos = 4
            else:
                a = line.readContainerStruct(data[3:], True)
                _data[id] = a[0]
                nextPos = a[1] + 4
        elif data[0] == 13:
            # dict
            # 0D 00 24 0B 0B 00 00 00 02 00 00 00 07
            # what is 24?
            a = data[4] # value type? todo it?
            b = data[8] # count
            c = 12
            _d = {}
            if b != 0:
                for d in range(b):
                    e = data[c] # key len
                    f = c + e
                    if data[3] == 8:
                        f = c + 1
                        g = data[c + 4]
                        _key = data[c]
                        h = f + 4 + g
                        _value = data[f + 4:h].decode()
                        c = h # ??
                    else:
                        g = int.from_bytes(data[f + 1:f + 5], "big") # value len
                        _key = data[c + 1:f + 1].decode()
                        h = f + g + 5
                        if a == 10:
                            __value = int.from_bytes(data[f+1:f+9], "big")
                            _value = __value
                            h = f + 9
                            c = h + 3
                        elif a == 12:
                            __value = line.readContainerStruct(data[f+1:], True)
                            _value = __value[0]
                            h = f + __value[1]
                            c = h
                        elif a == 15:
                            __value = line.readContainerStruct(data[f+1:], True)
                            _value = __value[0]
                            h = f + __value[1]
                            c = h + 1
                        else:
                            _value = data[f + 5:h].decode()
                            c = h + 3
                    _d[_key] = _value
                _data[id] = _d
                nextPos = c
                if a in [10, 11]:
                    nextPos -= 3
            else:
                nextPos = 9
                _data[id] = {}
        elif data[0] == 14:
            type = data[3]
            count = int.from_bytes(data[4:8], "big")
            _data[id] = []
            nextPos = 8
            if count != 0:
                for i in range(count):
                    a = int.from_bytes(data[nextPos:nextPos + 4], "big")
                    b = data[nextPos + 4:nextPos + 4 + a].decode()
                    _data[id].append(b)
                    nextPos += 4 + a
        elif data[0] == 15:
            type = data[3]
            d = data[7]
            _data[id] = []
            e = 8
            for _d in range(d):
                if type == 8:
                    f = int.from_bytes(data[e:e+4], "big")
                    _data[id].append(f)
                    e += 4
                elif type == 11:
                    f = data[e+3]
                    _data[id].append(data[e+4:e+4+f].decode())
                    e += f + 4
                elif type == 12:
                    f = line.readContainerStruct(data[e:], True)
                    _data[id].append(f[0])
                    if f[2] in [12, 13]:
                        e += f[1] + 1
                    else:
                        e += f[1] + 1
                else:
                    print(f"[readContainerStruct_LIST(15)]不支援Type: {type}")
            if not stopWithFirst:
                if d > 0:
                    nextPos += e
                else:
                    nextPos = 8
        elif data[0] != 0:
            print(f"[readContainerStruct]不支援Type: {data[0]} => ID: {id}")
        if nextPos > 0:
            data = data[nextPos:]
            c = line.readContainerStruct(data, True)
            if c[0]:
                _data.update(c[0])
                nextPos += c[1] # lol, why i forget it
                if c[2] != 0:
                    dataType = c[2]
        if get_data_len:
            return [_data, nextPos, dataType]
        return _data
        
    def tryReadTCompactData(line, data):
        _data = {}
        if data[4] == 130:
            a = 8 + data[7]
            b = data[8:a].decode()
            _data[b] = {}
            _dec = line.TCompactProtocol()
            (fname, ftype, fid, offset) = _dec.readFieldBegin(data[a:])
            offset += a + 1
            if ftype == 12:
                _data[b] = line.tryReadTCompactContainerStruct(data[a:])
                if 0 in _data[b]:
                    _data[b] = _data[b][0]
                else:
                    error = {
                        'code': _data[b][1][1],
                        'message': _data[b][1][2],
                        'metadata': _data[b][1].get(3, None)
                    }
                    if error['message'] in ["AUTHENTICATION_DIVESTED_BY_OTHER_DEVICE", "REVOKE", "LOG_OUT"]:
                        line.is_login = False
                        raise Exception(f"LOGIN OUT: {error['message']}")
                    _data[b] = {
                        "error": error
                    }
                    print(_data)
        return _data
        
    def tryReadTCompactContainerStruct(line, data, id=0, get_data_len=False):
        _data = {}
        _dec = line.TCompactProtocol()
        (fname, ftype, fid, offset) = _dec.readFieldBegin(data)
        nextPos = 0
        fid += id
        if ftype == 8:
            (_data[fid], nextPos) = _dec.readBinary(data[offset:])
        elif ftype == 2:
            _data[fid] = _dec.readBool()
            nextPos = 1
        elif ftype == 5:
            (_data[fid], nextPos) = _dec.readI32(data[offset:], True)
            nextPos += 1
        elif ftype == 9 or ftype == 10:
            ### todo:
            #       ftype == 10 == SET
            (vtype, vsize) = _dec.readCollectionBegin(data[offset:])
            offset += 1
            _data[fid] = []
            _nextPos = 0
            for i in range(vsize):
                if vtype == 8:
                    (__data, _nextPos) = _dec.readBinary(data[offset:])
                    _data[fid].append(__data)
                    offset += _nextPos - 1
            nextPos += offset
        elif ftype == 12:
            (__data, nextPos) = line.tryReadTCompactContainerStruct(data[offset:], get_data_len=True)
            nextPos += 2
            _data[fid] = __data
        elif ftype != 0:
            print(f"[tryReadTCompactContainerStruct]不支援Type: {ftype} => ID: {fid}")
        if nextPos > 0:
            data = data[nextPos:]
            c = line.tryReadTCompactContainerStruct(data, id=fid, get_data_len=True)
            if c[0]:
                _data.update(c[0])
                nextPos += c[1]
        if get_data_len:
            return [_data, nextPos]
        return _data
 
class LINE:
    """ LINE """

    class Config:
        """ LINE Config """

        # Headers
        USER_AGENT = "LLA/2.14.0 CPH1969 5.{}.{}".format(randomCount(),randomCount())
        APPLICATION = "ANDROIDLITE	2.14.0	Android OS	5.{}.{}".format(randomCount(),randomCount())
        #USER_AGENT = "LLA/2.9.1 SM-J320G 5.1.1" 
        #APPLICATION = "CHANNELCP	2.9.9	Android OS	5.6.0"
        #USER_AGENT = "Line/10.20.1"
        #APPLICATION = "ANDROID	10.20.1	Android OS	10" 
        #APPLICATION = "CHROMEOS\t2.3.9\tChrome OS\t2.1.5"
        
        #USER_AGENT = "Line/11.0.0 iPhone11,8 13.5.1" #"LLA/2.15.0 MI 8 10"
        #APPLICATION = "IOS\t11.0.0\tiOS\t{}" .format(randomCount())

        # Config
        REALTIME_CHATS = False
        
        FETCH_OPS_COUNT = 100
        
        
        # Keeper
        KEEPER_FILE_EXTENSION_NAME = "keeper"
        KEEPER_THREAD = False
        KEEPER_THREAD_SLEEP_INTERVAL = 10

        # Connection
        LINE_HOST =  "https://legy-jp-addr-long.line.naver.jp"
        #LINE_HOST =  "https://gd2.line.naver.jp"
        #LINE_HOST = "https://jp.never.line.android"
        #LINE_HOST = "https://ga2.line.naver.jp"
        TALK_PATH = "/S4"
        POLL_PATH = "/P4"

        # Service
        CONNECTOR = {
            "talk": (TALK_PATH, LineService.Client),
            "poll": (POLL_PATH, LineService.Client),
            "newtalk": (TALK_PATH, TalkService.Client),
            "newpoll": (POLL_PATH, TalkService.Client),
        }
        PROTOCOL = TCompactProtocolFactory

    class Keeper:
        """ LINE Keeper """
        __slots__ = {
            "token": None,
            "localRev": 0,
            "globalRev": 0,
            "individualRev": 0
        }

        def __init__(keeper, token):
            for attr, value in keeper.__slots__.items():
                setattr(keeper, attr, value)
            keeper.token = token
            keeper.load()

            if LINE.Config.KEEPER_THREAD:
                threading.Thread(target=keeper.auto, daemon=True).start()

        def load(keeper):
            try:
                with open(".".join([hashlib.md5(keeper.token.encode("utf-8")).hexdigest(), LINE.Config.KEEPER_FILE_EXTENSION_NAME]), "rb") as f:
                    for attr, value in pickle.load(f).items():
                        if attr in keeper.__slots__:
                            setattr(keeper, attr, value)
            except (FileNotFoundError, EOFError, pickle.UnpicklingError):
                return False
            return True

        def dump(keeper):
            return pickle.dumps({attr: getattr(keeper, attr, None) for attr in keeper.__slots__})

        def save(keeper):
            with open(".".join([hashlib.md5(keeper.token.encode("utf-8")).hexdigest(), LINE.Config.KEEPER_FILE_EXTENSION_NAME]), "wb+") as f:
                f.write(keeper.dump())

        def auto(keeper):
            while True:
                keeper.save()
                time.sleep(LINE.Config.KEEPER_THREAD_SLEEP_INTERVAL)

    class Session:
        """ LINE Session """

        class THttpClient:

            class Transport(TTransportBase):
                """ LINE Session Transport """

                def __init__(transport, client):
                    transport.client = client
                    transport.http = None
                    transport.last_read = 0
                    transport.wbuf = BytesIO()
                    transport.lock = threading.Lock()

                def isOpen(transport):
                    return transport.http is not None

                def open(transport):
                    transport.http = httplib2.Http(disable_ssl_certificate_validation=True)

                def close(transport):
                    if transport.isOpen():
                        transport.http.close()
                    transport.http = None
                    transport.last_read = 0
                    
                def read(transport, sz):
                    max_sz = transport.last_read + sz
                    min_sz = transport.last_read
                    transport.last_read = max_sz
                    return transport.data[min_sz:max_sz]

                def write(transport, buf):
                    transport.wbuf.write(buf)

                def flush(transport):
                    if not transport.isOpen():
                        transport.open()
                    data = transport.wbuf.getvalue()
                    transport.wbuf = BytesIO()
                    headers = {**{"Content-Type": "application/x-thrift"}, **transport.client.session.headers}
                    transport.response, transport.data = transport.http.request(transport.client.url, "POST", headers=headers, body=data)
                    transport.code = transport.response.status
                    transport.message = transport.response.reason
                    transport.headers = transport.response
                    transport.last_read = 0

            def __init__(self, client):
                self.client = client
                self.transportQueue = queue.LifoQueue(MAX_CONNECTIONS)
                self.semaphore = threading.BoundedSemaphore(MAX_CONNECTIONS)

            def createTransport(self):
                return self.Transport(self.client)

            @contextmanager
            def getTransport(self):
                self.semaphore.acquire()
                try:
                    transport = self.transportQueue.get(block=False)
                except queue.Empty:
                    transport = self.createTransport()
                try:
                    yield transport
                finally:
                    self.transportQueue.put(transport)
                    self.semaphore.release()

        class Client:
            """ LINE Session Client """
        
            def __init__(client, session, path, service):
                client.session = session
                client.path = path
                client.url = session.line.config.LINE_HOST + client.path
                client.transport = LINE.Session.THttpClient(client)
                client.service = ModThriftClient(copy.deepcopy(service))(client.transport, session.line.config.PROTOCOL())

        def __init__(session, line):
            assert isinstance(line, LINE)
            session.line = line
            session.headers = {
                "User-Agent": line.config.USER_AGENT,
                "X-Line-Application": line.config.APPLICATION,
                "X-Line-Access": session.line.keeper.token,
                "X-lal": "in_id",
            }
            session.connector = {name: LINE.Session.Client(session, *value) for name, value in line.config.CONNECTOR.items()}
            

        def __getattr__(session, key):
            if key in session.connector: return session.connector[key].service

    class RequestSequence:
        """ LINE Request Sequence """
    
        def __init__(reqSeq):
            reqSeq._map = {}
        
        def __getitem__(reqSeq, key):
            if key not in reqSeq._map:
                reqSeq._map[key] = -1
            reqSeq._map[key] += 1
            return reqSeq._map[key]

        def __setitem__(reqSeq, key, value):
            reqSeq._map[key] = value

        def __delitem__(reqSeq, key):
            del reqSeq._map[key]
            

    class RealtimeChats:
        """ LINE Realtime Chats """
        
        class Chat:
            __slots__ = (
                "chatMid",
                "chatName",
                "type",
                "members",
                "invites",
            )
        
            def __init__(rtchat, chat):
                rtchat.chatMid = chat.chatMid
                rtchat.chatName = chat.chatName
                rtchat.type = chat.type
                if rtchat.type in [ChatType.GROUP, ChatType.ROOM]:
                    rtchat.members = list(chat.extra.groupExtra.memberMids)
                    rtchat.invites = list(chat.extra.groupExtra.inviteeMids)
                else:
                    rtchat.members = []
                    rtchat.invites = []

            def __repr__(rtchat):
                return "%s(%s)" % (rtchat.__class__.__name__, ", ".join(["%s=%r" % (key, getattr(rtchat, key, None)) for key in rtchat.__slots__]))

        __type__ = {
            ChatType.GROUP: "groups",
            ChatType.ROOM: "rooms",
            ChatType.PEER: "peers",
        }
    
        def __init__(rtc, line):
            rtc.line = line
            rtc.groups = {}
            rtc.rooms = {}
            rtc.peers = {}

        def __setitem__(rtc, chatMid, chat):
            data = getattr(rtc, rtc.__type__[chat.type])
            data[chatMid] = LINE.RealtimeChats.Chat(chat)
        
        def __delitem__(rtc, chatMid):
            for key in rtc.__type__.values():
                data = getattr(rtc, key)
                if chatMid in data:
                    del data[chatMid]
        
        def __getitem__(rtc, chatMid):

            for key in rtc.__type__.values():
                data = getattr(rtc, key)
                if chatMid in data:
                    return data[chatMid]

            if not rtc.line.config.REALTIME_CHATS:
                return LINE.RealtimeChats.Chat(Chat())

            chat = rtc.line.getChat(chatMid)
            if not chat: return LINE.RealtimeChats.Chat(Chat())
            rtc[chatMid] = chat
            return rtc[chatMid]

        def __call__(rtc, op):

            # invite to chat
            if op.type in [OperationType.INVITE_INTO_GROUP, OperationType.NOTIFIED_INVITE_INTO_GROUP, OperationType.INVITE_INTO_CHAT, OperationType.NOTIFIED_INVITE_INTO_CHAT]:
                chat = rtc[op.param1]
                if op.param3:
                    for mid in op.param3.split("\x1e"):
                        if mid not in chat.invites:
                            chat.invites.append(mid)

            # cancel chat invitation
            if op.type in [OperationType.NOTIFIED_CANCEL_INVITATION_GROUP, OperationType.CANCEL_INVITATION_GROUP, OperationType.CANCEL_CHAT_INVITATION, OperationType.NOTIFIED_CANCEL_CHAT_INVITATION]:
                chat = rtc[op.param1]
                if op.param3:
                    for mid in op.param3.split("\x1e"):
                        if mid in chat.invites:
                            chat.invites.remove(mid)

            # reject chat invitation
            if op.type in [OperationType.REJECT_GROUP_INVITATION, OperationType.NOTIFIED_REJECT_GROUP_INVITATION, OperationType.REJECT_CHAT_INVITATION]:
                chat = rtc[op.param1]
                if op.param2:
                    for mid in op.param2.split("\x1e"):
                        if mid in chat.invites:
                            chat.invites.remove(mid)

            # delete other from chat
            if op.type in [OperationType.KICKOUT_FROM_GROUP, OperationType.NOTIFIED_KICKOUT_FROM_GROUP, OperationType.DELETE_OTHER_FROM_CHAT, OperationType.NOTIFIED_DELETE_OTHER_FROM_CHAT]:
                chat = rtc[op.param1]
                if op.param3:
                    for mid in op.param3.split("\x1e"):
                        if mid in chat.members:
                            chat.members.remove(mid)
                if op.param2:
                    if op.param2 == rtc.line.profile.mid:
                        del rtc[op.param1]

            # accept chat invitation
            if op.type in [OperationType.ACCEPT_GROUP_INVITATION, OperationType.NOTIFIED_ACCEPT_GROUP_INVITATION, OperationType.ACCEPT_CHAT_INVITATION, OperationType.NOTIFIED_ACCEPT_CHAT_INVITATION]:
                chat = rtc[op.param1]
                if op.param2:
                    for mid in op.param2.split("\x1e"):
                        if mid not in chat.members:
                            chat.members.append(mid)

            # leave chat
            if op.type in [OperationType.LEAVE_GROUP, OperationType.NOTIFIED_LEAVE_GROUP, OperationType.DELETE_SELF_FROM_CHAT, OperationType.NOTIFIED_DELETE_SELF_FROM_CHAT]:
                chat = rtc[op.param1]
                if op.param2:
                    for mid in op.param2.split("\x1e"):
                        if mid in chat.members:
                            chat.members.remove(mid)

                if op.type in [OperationType.LEAVE_GROUP, OperationType.DELETE_SELF_FROM_CHAT]:
                    del rtc[op.param1]

            if op.type in [26,25]:
                msg = op.message
                if msg.contentType == 18:
                    key = msg.contentMetadata["LOC_KEY"]
                    args = msg.contentMetadata["LOC_ARGS"].split("\x1e")
                    chat = rtc[op.param1]
                    if key == "C_MI": # invite
                        if args[1] not in chat.invites:
                            chat.invites.append(args[1])
                    if key == "C_IC": # cancel
                        if args[1] in chat.invites:
                            chat.invites.remove(args[1])


    class Kaboom:
    	def __init__(self, client,group,target):
    		self.client = client
    		self.execute(group, target)
    
    
    	
        #

    	async def fetch(self, url, session, data, headers):
    		async with session.post(url=url, data=data, headers=headers) as response:
    			return await response.read()

    	async def bound_fetch(self, sem, url, session, data, headers):
    		async with sem:
    			await self.fetch(url, session, data, headers)

    	async def run(self, auth, gid, uids):
    		url = "https://legy-jp-addr-long.line.naver.jp/S4"
    		datas = []
    		for uid in uids:
    			#data = '\x82!\x00\x10kickoutFromGroup\x15\x00\x18!%s\x19\x18!%s\x00' % (gid, uid)
    			#data = b'\x82!\x00\x10kickoutFromGroup\x15\x00\x18!'+gid.encode()+b'\x19\x18!'+uid.encode()+b'\x00'
    			data = '\x82!\x00\nleaveGroup\x15\x00\x18!%s\x00' % (gid)
    			datas.append(data.encode())
    		headers = {
    			'Content-Type': 'application/x-thrift',
    			'User-Agent': 'LLA/2.14.0 CPH1969 5.{}.{}'.format(randomCount(),randomCount()),
    			'X-Line-Application': 'IOS\t11.0.0\tiOS\t{}'.format(randomCount()),
    			'Content-Length': str(len(datas[0])),
    			'X-Line-Access': auth
    		}
    		tasks = []
    		sem = asyncio.Semaphore(1000)
    		async with ClientSession() as session:
    			for data in datas:
    				task = asyncio.ensure_future(self.bound_fetch(sem, url, session, data, headers))
    				tasks.append(task)
    			responses = asyncio.gather(*tasks)
    			await responses

    	def execute(self, gid, uids):
    		loop = asyncio.new_event_loop()
    		asyncio.set_event_loop(loop)
    		future = asyncio.ensure_future(self.run(self.client.authToken, gid, uids))
    		loop.run_until_complete(future)
    		
    


    def __init__(line, keeper):
        assert isinstance(keeper, LINE.Keeper)
        line.config = LINE.Config()
        line.keeper = keeper
        line.session = LINE.Session(line)
        line.reqSeq = LINE.RequestSequence()
        line.chats = LINE.RealtimeChats(line)
        line.profile = line.getProfile()
        line.Mid = line.getProfile().mid
        line.contacts = line.getAllContactIds()
        line.authToken = line.keeper.token
        line.header = line.getHeader()
        line.limit = False
        line.count = {"kick":0,"invite":0,"cancel":0,"msg":0,"accept":0,"allreq":0}
        line.logo = "n̶o̶o̶b̶i̶e̶z̶-𝐓𝐄𝐀𝐌"
        line.prefix = ","
        line._messageReq = {}
        line.models = Models()
        line.server = Server()
        line.server.Headers = line.getHeader()
        line.url = "https://legy-jp-addr-long.line.naver.jp/S4"
        #line.operationSelf = asyncio.get_event_loop()

    def getHeader(line):
    	Headers={'User-Agent': line.config.USER_AGENT, 'X-Line-Application': line.config.APPLICATION, 'X-Line-Access': line.keeper.token, 'X-Line-Carrier': '51089, 1-0' }
    	return Headers

    def getProfile(line, syncReason=SyncReason.FULL_SYNC):
        line.profile = line.session.talk.getProfile(syncReason)
        return line.profile

    def getContact(line, userIds):
    	return line.session.talk.getContact(userIds)

    def createChat(line, name, targetUserMids=[]):
    	return line.session.talk.createChat(CreateChatRequest(0, 0, name, targetUserMids, ''))

    def kbm(line,group,target):
    	return LINE.Kaboom(line,group,target)
    	
    def stateQr(line, to):
    	gc = line.getChats([to],False,False)
    	state=gc[0].extra.groupExtra.preventedJoinByTicket
    	return state

    def getMidUser(line, to):
    	gc = line.getChats([to],True,True)
    	mem=gc[0].extra.groupExtra.memberMids
    	pen=gc[0].extra.groupExtra.inviteeMids
    	return mem,pen

    def accByKicked(line, to,ticket):
    	gc = line.getChats([to],False,False)
    	state=gc[0].extra.groupExtra.preventedJoinByTicket
    	if not state:
    		return line.session.talk.acceptChatInvitationByTicket(AcceptChatInvitationByTicketRequest(line.reqSeq["acceptChatInvitationByTicket"], chatMid=to, ticketId=ticket))

    def updateProfile(line, objek):
    	return line.session.talk.updateProfile(0, objek)

    def unsendMessage(line, msgId):
        return line.session.talk.unsendMessage(line.reqSeq["unsendMessage"], msgId)

    def sendMessage2(line, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to = to
        msg._from = line.profile.mid
        msg.text = text
        msg.contentType = contentType
        msg.contentMetadata = contentMetadata
        line.count["msg"] += 1
        if to not in line._messageReq:
            line._messageReq[to] = -1
        line._messageReq[to] += 1
        return line.session.newtalk.sendMessage(line._messageReq[to], msg)

    def generateReplyMessage(line, relatedMessageId):
        msg = Message()
        msg.relatedMessageServiceCode = 1
        msg.messageRelationType = 3
        msg.relatedMessageId = str(relatedMessageId)
        return msg

    def sendReplyMessage(line, relatedMessageId, to, text, contentMetadata={}, contentType=0):
        msg = line.generateReplyMessage(relatedMessageId)
        msg.to = to
        msg.text = text
        msg.contentType = contentType
        msg.contentMetadata = contentMetadata
        line.count["msg"] += 1
        if to not in line._messageReq:
            line._messageReq[to] = -1
        line._messageReq[to] += 1
        return line.session.newtalk.sendMessage(line._messageReq[to], msg)

    def sendMessageObject(line, msg):
        return line.session.talk.sendMessage(line.reqSeq["sendMessage"], msg)

    def sendMentionV2(line, id, to, text="", mids=[], isUnicode=False):
        arrData = ""
        arr = []
        mention = "@noobiez "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ""
            unicode = ""
            if isUnicode:
                for mid in mids:
                    unicode += str(texts[mids.index(mid)].encode('unicode-escape'))
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx) if unicode == textx else len(textx) + unicode.count('U0')
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            else:
                for mid in mids:
                    textx += str(texts[mids.index(mid)])
                    slen = len(textx)
                    elen = len(textx) + 15
                    arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                    arr.append(arrData)
                    textx += mention
            textx += str(texts[len(mids)])
        else:
            raise Exception("Invalid mention position")
        line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0, msgid=id)

    def sendMention2(line,to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        line.sendMessage(to, textx, {'AGENT_LINK': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQE1AudGwwa9foK_ajhoKCnffSbO6WJQFMj-g&usqp=CAU','AGENT_ICON': "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQE1AudGwwa9foK_ajhoKCnffSbO6WJQFMj-g&usqp=CAU",'AGENT_NAME': ps,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)        


    def sendMessage(line, to, text, contentMetadata={}, contentType=0,msgid=None):
        #msg = line.generateReplyMessage(relatedMessageId)
        msg = Message()
        if 'MENTION' in contentMetadata.keys()!=None:
            try:
                msg.relatedMessageId = str(line.talk.getRecentMessagesV2(to, 10)[0].id)
                msg.relatedMessageServiceCode = 1
                msg.messageRelationType = 3
            except:
                pass
        if msgid != None:
            msg.relatedMessageId = str(msgid)
            msg.relatedMessageServiceCode = 1
            msg.messageRelationType = 3
        msg.to, msg._from = to, line.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in line._messageReq:
            line._messageReq[to] = -1
        line._messageReq[to] += 1
        line.count["msg"] += 1
        return line.session.talk.sendMessage(line._messageReq[to], msg)
        

    def sendContact(line, to, mid):
        return line.sendMessage(to, "", {"mid": mid}, ContentType.CONTACT)

    def getAllChatMids(line, withMemberChats=True, withInvitedChats=True, syncReason=SyncReason.FULL_SYNC):
        return line.session.talk.getAllChatMids(request=GetAllChatMidsRequest(withMemberChats=withMemberChats, withInvitedChats=withInvitedChats), syncReason=syncReason)

    def getChats(line, chatMids, withMembers=True, withInvitees=True):
        return line.session.talk.getChats(GetChatsRequest(chatMids=chatMids, withMembers=withMembers, withInvitees=withInvitees)).chats

    def getCompactGroup(line, groupId):
        return line.session.newtalk.getCompactGroup(groupId)

    def getGroup(line, groupId):
        return line.session.newtalk.getGroup(groupId)

    def updateGroup(line, groupId):
        return line.session.newtalk.updateGroup(0, groupId)
    
    def getChat(line, chatMid, withMembers=True, withInvitees=True):
        chats = line.getChats([chatMid], withMembers=withMembers, withInvitees=withInvitees)
        if chats:
            return chats[0]

    def acceptChatInvitation(line, chatMid):
    	line.count["allreq"] += 1
    	try:line.session.talk.acceptChatInvitation(AcceptChatInvitationRequest(line.reqSeq["acceptChatInvitation"], chatMid=chatMid));return
    	except:return
         
    def updateChat(line, chatId, updatedAttribute):
        line.count["allreq"] += 1
        return line.session.talk.updateChat(UpdateChatRequest(line.reqSeq["updateChat"], chatId, updatedAttribute))

    def acceptChatInvitationByTicket(line, chatMid, ticketId):
        line.count["accept"] += 1
        return line.session.talk.acceptChatInvitationByTicket(AcceptChatInvitationByTicketRequest(line.reqSeq["acceptChatInvitationByTicket"], chatMid=chatMid, ticketId=ticketId))

    def acceptGroupInvitationByTicket(line, groupId, ticketId):
        line.count["accept"] += 1
        return line.session.newtalk.acceptGroupInvitation(0, groupId)

    def inviteIntoChat(line, chatMid, targetUserMids):
        line.count["invite"] += 1
        return line.session.talk.inviteIntoChat(InviteIntoChatRequest(line.reqSeq["inviteIntoChat"], chatMid=chatMid, targetUserMids=set(targetUserMids)))

    def cancelChatInvitation(line, chatMid, targetUserMids):
        line.count["cancel"] += 1
        return line.session.talk.cancelChatInvitation(CancelChatInvitationRequest(line.reqSeq["cancelChatInvitation"], chatMid=chatMid, targetUserMids=set({targetUserMids})))

    def cancelGroupInvitation(line, groupId, userIds):
        line.count["cancel"] += 1
        return line.session.newtalk.cancelGroupInvitation(0, groupId, [userIds])
        	
    def rejectChatInvitation(line, chatMid):
        line.count["allreq"] += 1
        return line.session.talk.rejectChatInvitation(CancelChatInvitationRequest(line.reqSeq["rejectChatInvitation"], chatMid=chatMid))

    def deleteOtherFromChat(line, chatMid, targetUserMids):
        line.count["kick"] += 1
        return line.session.talk.deleteOtherFromChat(DeleteOtherFromChatRequest(line.reqSeq["deleteOtherFromChat"], chatMid=chatMid, targetUserMids=set(targetUserMids)))
    

    def deleteSelfFromChat(line, chatMid):
        line.count["allreq"] += 1
        return line.session.talk.deleteSelfFromChat(DeleteSelfFromChatRequest(line.reqSeq["deleteSelfFromChat"], chatMid=chatMid))

    def reissueChatTicket(line, groupMid):
        line.count["allreq"] += 1
        return line.session.talk.reissueChatTicket(ReissueChatTicketRequest(line.reqSeq["reissueChatTicket"], groupMid=groupMid)).ticketId
        
    def findChatByTicket(line, ticketId):
        line.count["allreq"] += 1
        return line.session.talk.findChatByTicket(FindChatByTicketRequest(ticketId)).chat

    def getAllContactIds(line, syncReason=SyncReason.FULL_SYNC):
        return line.session.talk.getAllContactIds(syncReason)

    def findAndAddContactsByMid(line, mid, type=ContactType.MID, reference=""):
        line.count["allreq"] += 1
        if mid in line.contacts or mid == line.profile.mid: return
        return line.session.talk.findAndAddContactsByMid(line.reqSeq["findAndAddContactsByMid"], mid, type, reference)

    def getRecentMessagesV2(line, chatId, count=1001):
        line.count["allreq"] += 1
        return line.session.talk.getRecentMessagesV2(chatId,count)

    def sendMention(line, to, text='',  mids=[]):
    	arrData = ""
    	arr = []
    	mention = "@Noobiez "
    	if mids == []:
    		raise Exception("Invalid mids")
    	if "􀜆􀅔Har Har􏿿" in text:
    		if text.count("􀜆􀅔Har Har􏿿") != len(mids):
    			raise Exception("Invalid mids")
    		texts = text.split("􀜆􀅔Har Har􏿿")
    		textx = ""
    		for mid in mids:
    			textx += str(texts[mids.index(mid)])
    			slen = len(textx)
    			elen = str(len(textx) + len(mention)-1)
    			arrData = {'S':str(slen),'E':str(elen),'M':mid}
    			arr.append(arrData)
    			textx += mention
    		textx += str(texts[len(mids)])
    	else:
    		textx = ""
    		slen = len(textx)
    		elen = str(len(textx) + len(mention)-1)
    		arrData = {'S':str(slen),'E':str(elen),'M':mids[0]}
    		arr.append(arrData)
    		textx += mention + str(text)
    	line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

    def sendMentionWithList(line, to, info, list):
    	h = [a for a in list]
    	k = len(h)//20
    	for aa in range(k+1):
    		if aa == 0: dd = f'╭ ◤  {info} ◥'; no=aa
    		else: dd = ''; no=aa*20
    		msgas = dd
    		for a in h[aa*20:(aa+1)*20]:
    			no+=1
    			if no == len(h): msgas+='\n│▸{}. 􀜆􀅔Har Har􏿿'.format(no)
    			else: msgas += '\n│▸{}. 􀜆􀅔Har Har􏿿'.format(no)
    		msgas += '\n╰ ◣ '+line.logo+' ◢'
    		line.sendMention(to, msgas, h[aa*20:(aa+1)*20])
    def saveValue(line):
    	line.tempe[line.Mid] += line.keeper.localRev
    	return line.tempe[line.Mid]
    
    def downloadMsg(line, msgid, name= ".bin"):
        path = '{}'.format(name)
        r = requests.session().get( 'https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+msgid, headers=line.header, stream=True)
        if r.status_code == 200:
            with open(path, 'wb') as f:
                shutil.copyfileobj(r.raw, f)
            return path
        else:
            raise Exception('Download object failure.')
    def removeAllMessages(line, lastMessageId):
    	return line.session.talk.removeAllMessages(line.reqSeq["removeAllMessages"], lastMessageId)
    
    def realFetchOps(line):
        try:
            ops = line.session.poll.fetchOps(line.keeper.localRev, line.config.FETCH_OPS_COUNT, line.keeper.globalRev, line.keeper.individualRev)
        except : #EOFError
            # timeout
            return []
        for op in ops:
        	#if op.revision > line.keeper.localRev:
        		if op.type != OperationType.END_OF_OPERATION:
        			line.keeper.localRev = max(line.keeper.localRev, op.revision)
        			#line.chats(op)
        		else:
        			if op.param1:
        				a, _, _ = op.param1.partition("")
        				line.keeper.individualRev = int(a)
        			if op.param2:
        				a, _, _ = op.param2.partition("")
        				line.keeper.globalRev = int(a)
        		#print(line.keeper.localRev)
        return ops

    def deleteOtherFromChat2(line, to, mid):
        _headers = {
            'X-Line-Access': line.authToken, 
            'x-lpqs': "/S3"
        }
        if type(mid) is 'list':
            _lastReq = None
            for _mid in mid:
                print(f'[deleteOtherFromChat] The parameter \'mid\' should be str')
                _lastReq = line.deleteOtherFromChat2(to, _mid)
            return _lastReq
        a = line.models.encHeaders(_headers)
        sqrd = [128, 1, 0, 1, 0, 0, 0, 19, 100, 101, 108, 101, 116, 101, 79, 116, 104, 101, 114, 70, 114, 111, 109, 67, 104, 97, 116, 0, 0, 0, 0]
        sqrd += [12, 0, 1]
        sqrd += [8, 0, 1, 0, 0, 0, 0] # seq?
        sqrd += [11, 0, 2, 0, 0, 0, len(to)]
        for value in to:
            sqrd.append(ord(value))
        sqrd += [14, 0, 3, 11, 0, 0, 0, 1, 0, 0, 0, len(mid)]
        for value in mid:
            sqrd.append(ord(value))
        sqrd += [0, 0]
        sqr_rd = a + sqrd
        _data = bytes(sqr_rd)
        data = line.models.encData(_data)
        res = line.server.postContent(line.url, data=data, headers=line.server.Headers)
        data = line.models.decData(res.content)
        print(line.models.tryReadData(data))
        return line.models.tryReadData(data)

    def getSettings(line):
        _headers = {
            'X-Line-Access': line.authToken, 
            'x-lpqs': "/S3"
        }
        a = line.models.encHeaders(_headers)
        sqrd = [128, 1, 0, 1, 0, 0, 0, 11, 103, 101, 116, 83, 101, 116, 116, 105, 110, 103, 115, 0, 0, 0, 0, 0]
        sqr_rd = a + sqrd
        _data = bytes(sqr_rd)
        data = line.models.encData(_data)
        res = line.server.postContent(line.url, data=data, headers=line.server.Headers)
        data = line.models.decData(res.content)
        return line.models.tryReadData(data)['getSettings']
        

    def updateChatURL(line,to, boolean):
    	gc = line.getChats([to],False,False)
    	gc[0].extra.groupExtra.preventedJoinByTicket = boolean
    	return line.updateChat(gc[0],4)
   
   