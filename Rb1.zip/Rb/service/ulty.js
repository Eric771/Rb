const thrifts = require('thrift');
const LineService = require('./thriftjs/TalkService');
const { DeleteOtherFromChatRequest, CancelChatInvitationRequest } = require('./thriftjs/ChatService_types');

var gid = '';
var uids = [];
var cuids = [];
var token = ''; 
// var service = 'ANDROIDLITE\t2.15.0\tAndroid OS\t5.1.1';

process.argv.forEach(function (val) {
  if(val.includes('gid=')){
      gid = val.split('gid=').pop();
  }else if(val.includes('uid=')){
      uids.push(val.split('uid=').pop());
  }else if(val.includes('token=')){
      token = val.split('token=').pop();
  }else if(val.includes('cud=')){
      cuids.push(val.split('cud=').pop());
  }
});
var options={
    protocol: thrifts.TCompactProtocol,
    transport: thrifts.TBufferedTransport,
    //headers: {'User-Agent':'LLA/2.15.0 G011A 5.1.1','X-Line-Application':service,'X-Line-Access':token },
    headers: {'User-Agent': 'LLA/2.14.0 CPH1969 10', 'X-Line-Application': 'ANDROIDLITE	2.14.0	Android OS	10', 'X-Line-Access': token},
    path: '/S4',
    https: true
    }
var connection = thrifts.createHttpConnection('legy-jp-addr-long.line.naver.jp', 443, options);
connection.on('error', (err) => { console.log('err',err); return err; });
var _client = thrifts.createHttpClient(LineService, connection);

async function deleteOtherFromChat(chatId, userIds = []) {
    let dd = new DeleteOtherFromChatRequest();
    dd.reqSeq = 0;
    dd.chatMid = chatId;
    dd.targetUserMids = userIds;
    return _client.deleteOtherFromChat(dd);
}

async function startOperation() {
    if (uids!==[]){
        for (var i=0; i < uids.length; i++) {
            deleteOtherFromChat(gid, [uids[i]]);
        }
    }
}

startOperation();